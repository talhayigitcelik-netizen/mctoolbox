package com.toolbox.mc

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private data class Cmd(val label: String, val cmd: String)

    // Minecraft Bedrock komutları. Kendi dünyanda (cheat açık) veya
    // komut yetkin olan sunucularda çalışır.
    private val sections: Map<String, List<Cmd>> = linkedMapOf(
        "Oyun Modu" to listOf(
            Cmd("Yaratıcı", "/gamemode creative"),
            Cmd("Hayatta Kalma", "/gamemode survival"),
            Cmd("Macera", "/gamemode adventure"),
            Cmd("İzleyici", "/gamemode spectator"),
        ),
        "Zaman ve Hava" to listOf(
            Cmd("Gündüz", "/time set day"),
            Cmd("Gece", "/time set night"),
            Cmd("Öğle", "/time set noon"),
            Cmd("Hava açık", "/weather clear"),
            Cmd("Yağmur", "/weather rain"),
            Cmd("Fırtına", "/weather thunder"),
            Cmd("Gün döngüsünü durdur", "/gamerule dodaylightcycle false"),
            Cmd("Gün döngüsünü aç", "/gamerule dodaylightcycle true"),
        ),
        "Oyuncu" to listOf(
            Cmd("Canı doldur", "/effect @s instant_health 1 10 true"),
            Cmd("Açlığı doldur", "/effect @s saturation 1 10 true"),
            Cmd("Gece görüşü", "/effect @s night_vision 99999 0 true"),
            Cmd("Hız", "/effect @s speed 99999 2 true"),
            Cmd("Yüksek zıplama", "/effect @s jump_boost 99999 3 true"),
            Cmd("Su altı nefesi", "/effect @s water_breathing 99999 0 true"),
            Cmd("Efektleri temizle", "/effect @s clear"),
            Cmd("100 seviye XP", "/xp 100L @s"),
            Cmd("Envanteri temizle", "/clear @s"),
        ),
        "Eşya" to listOf(
            Cmd("Elmas kılıç", "/give @s diamond_sword"),
            Cmd("Elmas kazma", "/give @s diamond_pickaxe"),
            Cmd("Netherite kılıç", "/give @s netherite_sword"),
            Cmd("Netherite kazma", "/give @s netherite_pickaxe"),
            Cmd("Altın elma x16", "/give @s golden_apple 16"),
            Cmd("Ender incisi x16", "/give @s ender_pearl 16"),
            Cmd("Elytra", "/give @s elytra"),
            Cmd("Havai fişek x64", "/give @s firework_rocket 64"),
            Cmd("Kalkan", "/give @s shield"),
            Cmd("TNT x16", "/give @s tnt 16"),
            Cmd("Yatak", "/give @s bed"),
            Cmd("Eldeki eşyayı büyüle", "/enchant @s sharpness 5"),
        ),
        "Işınlanma" to listOf(
            Cmd("Gökyüzüne çık (y=320)", "/tp @s ~ 320 ~"),
            Cmd("10 blok yukarı", "/tp @s ~ ~10 ~"),
            Cmd("Köy bul", "/locate structure village"),
            Cmd("Biyom bul: Cherry", "/locate biome cherry_grove"),
            Cmd("Spawn noktasını buraya koy", "/setworldspawn ~ ~ ~"),
        ),
        "Dünya Kuralları" to listOf(
            Cmd("Ölünce eşya kaybetme", "/gamerule keepinventory true"),
            Cmd("Mob zararı kapat", "/gamerule mobgriefing false"),
            Cmd("Anında yeniden doğma", "/gamerule doimmediaterespawn true"),
            Cmd("Zorluk: Huzurlu", "/difficulty peaceful"),
            Cmd("Zorluk: Zor", "/difficulty hard"),
            Cmd("Yerdeki eşyaları sil", "/kill @e[type=item]"),
        ),
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("minecraft komutu", text))
        Toast.makeText(this, "Kopyalandı: $text", Toast.LENGTH_SHORT).show()
    }

    private fun roundBg(color: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(10).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#1B1B1F"))
            addView(root)
        }

        root.addView(TextView(this).apply {
            text = "MC Toolbox"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "Butona bas, komut kopyalansın. Minecraft'ta sohbeti aç ve yapıştır. " +
                "Dünyada hile (cheats) açık olmalı."
            textSize = 13f
            setTextColor(Color.parseColor("#B0B0B8"))
            setPadding(0, dp(4), 0, dp(16))
        })

        // Özel komut alanı
        val input = EditText(this).apply {
            hint = "/komutunu yaz"
            setHintTextColor(Color.parseColor("#80808A"))
            setTextColor(Color.WHITE)
            setSingleLine(true)
            background = roundBg(Color.parseColor("#2A2A30"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val copyBtn = Button(this).apply {
            text = "Kopyala"
            setTextColor(Color.WHITE)
            background = roundBg(Color.parseColor("#3B8C3B"))
            setOnClickListener {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) copy(t)
            }
        }
        val customRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        customRow.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        customRow.addView(copyBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { leftMargin = dp(8) })
        root.addView(customRow)

        for ((title, cmds) in sections) {
            root.addView(TextView(this).apply {
                text = title
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.parseColor("#7FD67F"))
                setPadding(0, dp(20), 0, dp(8))
            })

            // 2 sütunlu ızgara
            var row: LinearLayout? = null
            cmds.forEachIndexed { i, c ->
                if (i % 2 == 0) {
                    row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    root.addView(row)
                }
                val b = Button(this).apply {
                    text = c.label
                    transformationMethod = null
                    textSize = 13f
                    setTextColor(Color.WHITE)
                    background = roundBg(Color.parseColor("#34343C"))
                    setOnClickListener { copy(c.cmd) }
                }
                row!!.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
                // Tek sayıda buton varsa boşluk ekle
                if (i == cmds.lastIndex && cmds.size % 2 == 1) {
                    row!!.addView(TextView(this), LinearLayout.LayoutParams(0, dp(48), 1f))
                }
            }
        }

        setContentView(scroll)
    }
}
